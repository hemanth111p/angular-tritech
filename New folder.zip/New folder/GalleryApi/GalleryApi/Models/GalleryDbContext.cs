﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GalleryApi.Models
{
    public class GalleryDbContext :DbContext
    {
        public GalleryDbContext(DbContextOptions<GalleryDbContext> options) : base(options)
        {

        }
        public DbSet<Models.GalleryModel> GalleryDbTable { get; set; }
    }
}
