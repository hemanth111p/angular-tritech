﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GalleryApi.Models;
using GalleryApi.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace GalleryApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GalleryController : ControllerBase
    {
         readonly IGalleryRepository galleryRepository;

        public GalleryController(IGalleryRepository repository)
        {
            this.galleryRepository = repository;

        }
        [HttpGet]
        public IActionResult Display()
        {
            var data = galleryRepository.GetAllFiles();
            return Ok(data);
        }
        [HttpPost]
        public IActionResult Create([FromBody] Models.GalleryModel galleryModel)
        {
            Boolean isInserted = galleryRepository.Addfile(galleryModel);
            var inserted = galleryRepository.CheckStatus(isInserted);
            return Ok(inserted); 
        }
        [HttpPut]
        public IActionResult Edit([FromBody] Models.GalleryModel galleryModel)
        {
            Boolean isUpdate = galleryRepository.UpdateFile(galleryModel);
            var isUpdated = galleryRepository.CheckStatus(isUpdate);
            return Ok(isUpdated + "fully updated");
        }
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            Boolean isDeleted = galleryRepository.DeleteFile(id);
            var isDelete = galleryRepository.CheckStatus(isDeleted);
            return Ok(isDelete);
        }

    }
}
