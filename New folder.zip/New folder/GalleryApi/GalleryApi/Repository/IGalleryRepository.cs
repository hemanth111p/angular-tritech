﻿using GalleryApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GalleryApi.Repository
{
    public interface IGalleryRepository
    {
        IEnumerable<GalleryModel> GetAllFiles();

        bool UpdateFile(GalleryModel fileUpdate);
        bool DeleteFile(int id);
        bool Addfile(GalleryModel fileAdd);
        string CheckStatus(bool condition);
    }
}
