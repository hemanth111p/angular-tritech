﻿using GalleryApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GalleryApi.Repository
{
    public class GalleryOrmRepository : IGalleryRepository
    {
        readonly private GalleryDbContext galleryDb;

        public GalleryOrmRepository(GalleryDbContext galleryDbContext)
        {
            this.galleryDb = galleryDbContext;
        }

        public bool Addfile(GalleryModel fileAdd)
        {
            galleryDb.GalleryDbTable.Add(fileAdd);
            return Convert.ToBoolean(galleryDb.SaveChanges());
        }

        public string CheckStatus(bool condition)
        {
            return condition ? "success" : "Failed";
        }

        public bool DeleteFile(int id)
        {
            Boolean rowsaffected = false;
            GalleryModel fileToDelete = galleryDb.GalleryDbTable.Where(x => x.Id == id).SingleOrDefault();
            if (fileToDelete != null)
            {
                galleryDb.GalleryDbTable.Remove(fileToDelete);
                rowsaffected = Convert.ToBoolean(galleryDb.SaveChanges());
            }
            return rowsaffected ? true : false;
        }

        public IEnumerable<GalleryModel> GetAllFiles()
        {
            return galleryDb.GalleryDbTable.ToList();
        }

        public bool UpdateFile(GalleryModel fileUpdate)
        {
            Boolean rowsaffected = false;
            GalleryModel fileToUpdate = galleryDb.GalleryDbTable.Where(x => x.Id == fileUpdate.Id).SingleOrDefault();
            if (fileToUpdate != null)
            {
                fileToUpdate.Filepath = fileUpdate.Filepath;
                rowsaffected = Convert.ToBoolean(galleryDb.SaveChanges());
            }
            return rowsaffected ? true : false;
        }
    }
}



