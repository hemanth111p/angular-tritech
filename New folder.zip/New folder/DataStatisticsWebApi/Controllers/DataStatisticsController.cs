using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DataStatisticsWebApi.Models;
using DataStatisticsWebApi.Repositories;
namespace DataStatisticsWebApi.Controllers
{
    [ApiController]
    [Route("api/{controller}")]
    public class DataStatisticsController : ControllerBase
    {
        Repositories.IDataStatisticsRepository dataLayer;
         public DataStatisticsController(IDataStatisticsRepository Data)
        {
            dataLayer = Data;
        }
        [HttpGet]
           public IEnumerable<DataStatisticsModel> GetAllDetails()
        {
            IEnumerable<DataStatisticsModel> data = dataLayer.GetAllDetails();
            return data;
        }
         [HttpPost]
         public string PostData([FromBody] DataStatisticsModel data)
        {
            Boolean isStatus = dataLayer.AddData(data);
            return GetStatus(isStatus, "Data Creation");
        }
        [HttpPut]
        public string PutData([FromBody] DataStatisticsModel data)
        {
            Boolean isStatus = dataLayer.UpdateData(data);
            return GetStatus(isStatus,"Data Updation");
        }
        [HttpDelete]
        [Route("deleteData/{id}")]
        public string DeleteData(int Id)
        {
            Boolean isStatus = dataLayer.DeleteData(Id);
            return GetStatus(isStatus,"Data Deletion");
        }
        [HttpGet]
        [Route("getData/{id}")]
         public DataStatisticsModel GetDataById(int Id)
        {
            return dataLayer.GetAllDetails().Where(data => data.Id == Id).FirstOrDefault();
        }
          private string GetStatus(Boolean status,string msg)
        {
            if(status)
                return msg + "  successfull";
            else
                return msg + "  Failed";
        }
    }
}