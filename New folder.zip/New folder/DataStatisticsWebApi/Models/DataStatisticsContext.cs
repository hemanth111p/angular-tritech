using Microsoft.EntityFrameworkCore;

namespace DataStatisticsWebApi.Models
{
public class DataStatisticsContext : DbContext
{
    public DbSet<DataStatisticsModel> DataStatistics
    {
        get;set;
    }
    public DataStatisticsContext(DbContextOptions<DataStatisticsContext> options) : base(options)
    {
        
    }
}
}