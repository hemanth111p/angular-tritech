﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using DataStatisticsWebApi.Models;
namespace DataStatisticsWebApi.Repositories
{
public class DataStatisticsRepository : IDataStatisticsRepository
{
    private readonly DataStatisticsContext context;
    public DataStatisticsRepository(DataStatisticsContext _dataStatistics)
    {
        context=_dataStatistics;
    }
	  public IEnumerable<DataStatisticsModel> GetAllDetails()
    {
        return context.DataStatistics;
        //throw new NotImplementedException();
    }
    public bool AddData(DataStatisticsModel data)
        {
            int rowsaffected = 0;
            context.DataStatistics.Add(data);
            rowsaffected = context.SaveChanges();
             return rowsaffected > 0 ? true : false;
        }
    public bool UpdateData(DataStatisticsModel data)
        {
            int rowsaffected = 0;
            DataStatisticsModel dataModel =context.DataStatistics.Where(u => u.Id== data.Id).FirstOrDefault();
             dataModel.Id = data.Id;
            dataModel.Title = data.Title;
            dataModel.Text = data.Text;
            dataModel.Value = data.Value;
            rowsaffected =context.SaveChanges();  
            return rowsaffected > 0 ? true : false;
        }
        public bool DeleteData(int Id)
        {
            int rowsaffected = 0;
            DataStatisticsModel data = context.DataStatistics.Where(x => x.Id == Id).FirstOrDefault();
            data.Id = Id;
            context.DataStatistics.Remove(data);
            rowsaffected =context.SaveChanges();  
            return rowsaffected > 0 ? true : false;
        }
}
}