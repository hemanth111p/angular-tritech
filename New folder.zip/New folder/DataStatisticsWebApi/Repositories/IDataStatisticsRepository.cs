using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DataStatisticsWebApi.Models;

namespace DataStatisticsWebApi.Repositories
{
     public interface IDataStatisticsRepository
    {
        
        IEnumerable<DataStatisticsModel> GetAllDetails();
         bool AddData(DataStatisticsModel data);
        bool DeleteData(int Id);
       
        bool UpdateData(DataStatisticsModel data); 
    }
}