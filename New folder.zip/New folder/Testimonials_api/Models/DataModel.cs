using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Testimonials_api.Models
{
    public class DataModel
    {
        
        public string ContentMsg { get; set; }
        public string ImageSource { get; set; }
        [Key]
        public string Name { get; set; }
        public string Role { get; set; }
    }
}