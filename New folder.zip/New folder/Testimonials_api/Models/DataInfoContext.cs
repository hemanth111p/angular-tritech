using Microsoft.EntityFrameworkCore;

namespace Testimonials_api.Models
{
public class DataInfoContext : DbContext
{
    public DbSet<DataModel> TestimonialsTable
    {
        get;set;
    }
     public DataInfoContext(DbContextOptions<DataInfoContext> options) : base(options)
        {
        }
}
}