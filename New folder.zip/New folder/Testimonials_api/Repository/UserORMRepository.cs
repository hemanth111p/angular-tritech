using Testimonials_api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Testimonials_api.Repository;


namespace Testimonials_api.Repository
{
    public class UserORMRepository : IUserDataRepository
    {
      DataInfoContext context;
      public UserORMRepository(DataInfoContext _context)
      {
          context=_context;
      }
      

        public bool AddData(DataModel data)
        {
            int rowsaffected = 0;
            context.TestimonialsTable.Add(data);
            rowsaffected = context.SaveChanges();
             return rowsaffected > 0 ? true : false;
        }

        public bool UpdateData(DataModel data)
        {
            int rowsaffected = 0;
            DataModel dataModel =context.TestimonialsTable.Where(u => u.Name== data.Name).FirstOrDefault();
            dataModel.ContentMsg = data.ContentMsg;
            dataModel.ImageSource = data.ImageSource;
            dataModel.Name = data.Name;
            dataModel.Role = data.Role;
            rowsaffected =context.SaveChanges();  
            return rowsaffected > 0 ? true : false;
        }

        public bool DeleteData(string name)
        {
            int rowsaffected = 0;
            DataModel data = context.TestimonialsTable.Where(x => x.Name == name).FirstOrDefault();
            data.Name = name;
            context.TestimonialsTable.Remove(data);
            rowsaffected =context.SaveChanges();  
            return rowsaffected > 0 ? true : false;
        }

        public IEnumerable<DataModel> GetAllData()
        {
            return context.TestimonialsTable;
        }

    }
}