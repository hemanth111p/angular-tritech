using Testimonials_api.Models;
using System.Collections.Generic;


namespace Testimonials_api.Repository
{
    public interface IUserDataRepository
    {
        bool AddData(DataModel data);
        bool DeleteData(string name);
        IEnumerable<DataModel> GetAllData();
        bool UpdateData(DataModel data);     
    }
}