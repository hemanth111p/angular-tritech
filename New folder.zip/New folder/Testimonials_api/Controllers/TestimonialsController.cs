using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Testimonials_api.Repository;
using Testimonials_api.Models;

namespace Testimonials_api.Controllers
{
    [ApiController]
    [Route("api/{controller}")]
    public class TestimonialsController : ControllerBase
    {
        Repository.IUserDataRepository dataLayer;
         public TestimonialsController(IUserDataRepository contentData)
        {
            dataLayer = contentData;
        }
        [HttpPost]
         public string PostData([FromBody] DataModel data)
        {
            Boolean isStatus = dataLayer.AddData(data);
            return GetStatus(isStatus, "Data Creation");
        }
        [HttpPut]
        public string PutData([FromBody] DataModel data)
        {
            Boolean isStatus = dataLayer.UpdateData(data);
            return GetStatus(isStatus,"Data Updation");
        }
        [HttpDelete]
        [Route("deleteData/{name}")]
        public string DeleteData(string name)
        {
            Boolean isStatus = dataLayer.DeleteData(name);
            return GetStatus(isStatus,"Data Deletion");
        }
        [HttpGet]
        public IEnumerable<DataModel> GetAllData()
        {
            IEnumerable<DataModel> datas = dataLayer.GetAllData();
            return datas;
        }
        [HttpGet]
        [Route("getData/{name}")]
        public DataModel GetDataByName(string name)
        {
            return dataLayer.GetAllData().Where(data => data.Name == name).FirstOrDefault();
        }
        private string GetStatus(Boolean status,string msg)
        {
            if(status)
                return msg + "  successfull";
            else
                return msg + "  Failed";
        }
    }
}
