using Microsoft.EntityFrameworkCore;

namespace SectionMenu.Models
{
public class SectionInfoContext : DbContext
{
    public DbSet<DataModel> SectionItemTable
    {
        get;set;
    }
     public SectionInfoContext(DbContextOptions<SectionInfoContext> options) : base(options)
        {
        }
}
}