using SectionMenu.Models;
using System.Collections.Generic;


namespace SectionMenu.Repository
{
    public interface IUserDataRepository
    {
        bool AddData(DataModel data);
        bool DeleteData(string name);
        IEnumerable<DataModel> GetAllData();
        bool UpdateData(DataModel data);     
    }
}