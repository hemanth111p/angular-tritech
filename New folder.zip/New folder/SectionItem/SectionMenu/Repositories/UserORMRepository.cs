using SectionMenu.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SectionMenu.Repository;

namespace SectionMenu.Repository
{
    public class UserORMRepository : IUserDataRepository
    {
      SectionInfoContext context;
      public UserORMRepository(SectionInfoContext _context)
      {
          context=_context;
      }
      

        public bool AddData(DataModel data)
        {
            int rowsaffected = 0;
            context.SectionItemTable.Add(data);
            rowsaffected = context.SaveChanges();
             return rowsaffected > 0 ? true : false;
        }

        public bool UpdateData(DataModel data)
        {
            int rowsaffected = 0;
            DataModel dataModel =context.SectionItemTable.Where(u => u.Title== data.Title).FirstOrDefault();
            dataModel.Title = data.Title;
            dataModel.Contents = data.Contents;
            rowsaffected =context.SaveChanges();  
            return rowsaffected > 0 ? true : false;
        }

        public bool DeleteData(string Title)
        {
            int rowsaffected = 0;
            DataModel data = context.SectionItemTable.Where(x => x.Title == Title).FirstOrDefault();
            data.Title = Title;
            context.SectionItemTable.Remove(data);
            rowsaffected =context.SaveChanges();  
            return rowsaffected > 0 ? true : false;
        }

        public IEnumerable<DataModel> GetAllData()
        {
            return context.SectionItemTable;
        }

    }
}