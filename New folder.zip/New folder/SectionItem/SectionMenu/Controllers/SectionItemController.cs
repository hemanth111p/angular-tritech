using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SectionMenu.Repository;
using SectionMenu.Models;

namespace SectionMenu.Controllers
{
    [ApiController]
    [Route("api/{controller}")]
    public class SectionInfoController : ControllerBase
    {
        Repository.IUserDataRepository dataLayer;
         public SectionInfoController(IUserDataRepository contentData)
        {
            dataLayer = contentData;
        }
        [HttpPost]
         public string PostData([FromBody] DataModel data)
        {
            Boolean isStatus = dataLayer.AddData(data);
            return GetStatus(isStatus, "Data Creation");
        }
        [HttpPut]
        public string PutData([FromBody] DataModel data)
        {
            Boolean isStatus = dataLayer.UpdateData(data);
            return GetStatus(isStatus,"Data Updation");
        }
        [HttpDelete]
        [Route("delete/{Title}")]
        public string DeleteData(string Title)
        {
            Boolean isStatus = dataLayer.DeleteData(Title);
            return GetStatus(isStatus,"Data Deletion");
        }
        [HttpGet]
        public IEnumerable<DataModel> GetAllData()
        {
            IEnumerable<DataModel> datas = dataLayer.GetAllData();
            return datas;
        }
        [HttpGet]
        [Route("get/{Title}")]
        public DataModel GetDataByName(string Title)
        {
            return dataLayer.GetAllData().Where(data => data.Title == Title).FirstOrDefault();
        }
        private string GetStatus(Boolean status,string msg)
        {
            if(status)
                return msg + "  successfull";
            else
                return msg + "  Failed";
        }
    }
}
