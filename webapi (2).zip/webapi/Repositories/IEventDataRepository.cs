using System.Collections.Generic;
using webapi.Models;

namespace webapi.Repositories
{
    public interface IEventDataRepository
    {
        
        IEnumerable<EventModel> GetallEvents();
        bool AddEvent(EventModel _event);
        bool DeleteEvent(int id);
        bool UpdateEvent(EventModel _event);
        
    }
}