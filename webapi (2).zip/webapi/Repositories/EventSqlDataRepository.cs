using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using webapi.Repositories;
using webapi.Models;
namespace webapi.Repositories
{
 public class EventSqlDataRepository : IEventDataRepository
    {
        EventContainerContext context;
      public EventSqlDataRepository(EventContainerContext _context)
      {
          context=_context;
      }
        public IEnumerable<EventModel> GetallEvents()
        {
            return context.eventConatiner;
        }
        public Boolean AddEvent(EventModel _event)
        {
            int rowsaffected = 0;
            context.eventConatiner.Add(_event);
            rowsaffected = context.SaveChanges();
             return rowsaffected > 0 ? true : false;
        }

     

        public Boolean UpdateEvent(EventModel _event)
        {
          int rowsaffected = 0;
            EventModel eventModel =context.eventConatiner.Where(u => u.Id == _event.Id).FirstOrDefault();
            eventModel.Title = _event.Title;
            eventModel.Location = _event.Location;
            eventModel.Date = _event.Date;
            eventModel.Description = _event.Description;
            rowsaffected =context.SaveChanges();  
            return rowsaffected > 0 ? true : false;
        }

        public Boolean DeleteEvent(int id)
        {
           int rowsaffected = 0;
            EventModel _event = context.eventConatiner.Where(x => x.Id == id).FirstOrDefault();
            _event.Id = id;
            context.eventConatiner.Remove(_event);
            rowsaffected =context.SaveChanges();  
            return rowsaffected > 0 ? true : false;
        }
    }
}