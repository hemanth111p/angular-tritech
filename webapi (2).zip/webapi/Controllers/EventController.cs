using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using webapi.Models;
using webapi.Repositories;

 [ApiController]
    [Route("api/[controller]")]
    public class EventController : ControllerBase
    {
         private  IEventDataRepository dbLayer;
        public EventController(IEventDataRepository _eventDataRepository)
        {
            dbLayer = _eventDataRepository;
        }
        
        
        [HttpGet]
        public IEnumerable<EventModel> GetUserEvents()
        {
            IEnumerable<EventModel> Events = dbLayer.GetallEvents();
            return Events;
        }

       [HttpPost]
        public string PostEventDetails([FromBody] EventModel _event)
        {
            Boolean isStatus = dbLayer.AddEvent(_event);
            return GetStatus(isStatus, "Create");
        }

         [HttpPut]
        public string PutEventDetail([FromBody] EventModel _event)
        {
            Boolean isStatus = dbLayer.UpdateEvent(_event);
            return GetStatus(isStatus, "Update");

        }

        [HttpDelete]
         [Route("EventDetail/{id}")]
        public string DeleteEventDetail(int id)
        {
            Boolean isStatus = dbLayer.DeleteEvent(id);
            return GetStatus(isStatus, "Delete");
        } 
        
        public string GetStatus(Boolean status, string message)
        {
            if (status)
                return message + " Event detail is successfull";
            else
                return message + " Event detail is Failed";
        }
    }
