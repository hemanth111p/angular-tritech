using Microsoft.EntityFrameworkCore;
using webapi.Models;

namespace webapi.Models
{
public class EventContainerContext : DbContext
{
    public DbSet<EventModel> eventConatiner
    {
        get;set;
    }
     public EventContainerContext(DbContextOptions<EventContainerContext> options) : base(options)
        {
        }
}
}